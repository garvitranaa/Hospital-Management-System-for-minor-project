using HospitalApp.Models;

namespace HospitalApp.Services
{
    public static class Storage
    {
        private static readonly string BaseDir = Path.Combine(AppContext.BaseDirectory, "data");
        private static readonly string PatientsFile = Path.Combine(BaseDir, "patients.csv");
        private static readonly string DoctorsFile = Path.Combine(BaseDir, "doctors.csv");
        private static readonly string AppointmentsFile = Path.Combine(BaseDir, "appointments.csv");

        static Storage()
        {
            if (!Directory.Exists(BaseDir))
            {
                Directory.CreateDirectory(BaseDir);
            }
        }

        public static List<Patient> LoadPatients()
        {
            var result = new List<Patient>();
            if (!File.Exists(PatientsFile)) return result;
            foreach (var line in File.ReadAllLines(PatientsFile))
            {
                var parts = line.Split(',');
                if (parts.Length < 6) continue;
                var patient = new Patient
                {
                    Id = parts[0],
                    FirstName = parts[1],
                    LastName = parts[2],
                    Phone = parts[3],
                    Email = parts[4],
                    Type = Enum.TryParse<PatientType>(parts[5], out var t) ? t : PatientType.Outpatient,
                };
                if (parts.Length > 6 && decimal.TryParse(parts[6], out var bill))
                {
                    patient.OutstandingBill = bill;
                }
                result.Add(patient);
            }
            return result;
        }

        public static void SavePatients(IEnumerable<Patient> patients)
        {
            var lines = patients.Select(p => string.Join(',', new string[]
            {
                p.Id,
                p.FirstName,
                p.LastName,
                p.Phone,
                p.Email,
                p.Type.ToString(),
                p.OutstandingBill.ToString()
            }));
            File.WriteAllLines(PatientsFile, lines);
        }

        public static List<Doctor> LoadDoctors()
        {
            var result = new List<Doctor>();
            if (!File.Exists(DoctorsFile)) return result;
            foreach (var line in File.ReadAllLines(DoctorsFile))
            {
                var parts = line.Split(',');
                if (parts.Length < 6) continue;
                var doc = new Doctor
                {
                    Id = parts[0],
                    FirstName = parts[1],
                    LastName = parts[2],
                    Phone = parts[3],
                    Email = parts[4],
                    Specialty = Enum.TryParse<Specialty>(parts[5], out var s) ? s : Specialty.General,
                    Room = parts.Length > 6 ? parts[6] : string.Empty
                };
                result.Add(doc);
            }
            return result;
        }

        public static void SaveDoctors(IEnumerable<Doctor> doctors)
        {
            var lines = doctors.Select(d => string.Join(',', new string[]
            {
                d.Id,
                d.FirstName,
                d.LastName,
                d.Phone,
                d.Email,
                d.Specialty.ToString(),
                d.Room
            }));
            File.WriteAllLines(DoctorsFile, lines);
        }

        public static List<Appointment> LoadAppointments()
        {
            var result = new List<Appointment>();
            if (!File.Exists(AppointmentsFile)) return result;
            foreach (var line in File.ReadAllLines(AppointmentsFile))
            {
                var parts = line.Split(',');
                if (parts.Length < 5) continue;
                var appt = new Appointment
                {
                    Id = parts[0],
                    PatientId = parts[1],
                    DoctorId = parts[2],
                    Date = DateTime.TryParse(parts[3], out var dt) ? dt : DateTime.Now,
                    Notes = parts[4]
                };
                result.Add(appt);
            }
            return result;
        }

        public static void SaveAppointments(IEnumerable<Appointment> appointments)
        {
            var lines = appointments.Select(a => string.Join(',', new string[]
            {
                a.Id,
                a.PatientId,
                a.DoctorId,
                a.Date.ToString("s"),
                a.Notes.Replace(',', ';')
            }));
            File.WriteAllLines(AppointmentsFile, lines);
        }
    }
}








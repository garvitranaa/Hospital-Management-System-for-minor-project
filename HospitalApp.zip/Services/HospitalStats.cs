namespace HospitalApp.Services
{
    public static class HospitalStats
    {
        public static int TotalPatients { get; private set; }
        public static decimal TotalRevenue { get; private set; }

        public static void IncrementPatients()
        {
            TotalPatients++;
        }

        public static void AddRevenue(decimal amount)
        {
            if (amount < 0) return;
            TotalRevenue += amount;
        }
    }
}








using System;

namespace HospitalApp.Exceptions
{
	public class InvalidPatientException : Exception
	{
		public InvalidPatientException(string message) : base(message) { }
	}

	public class BillingException : Exception
	{
		public BillingException(string message) : base(message) { }
	}
}



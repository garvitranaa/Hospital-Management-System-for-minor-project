using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using HospitalApp.Models;

namespace HospitalApp.Services
{
	public static class CsvStorage
	{
		private static readonly string BaseFolder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "data");

		public static void EnsureDataFolder()
		{
			if (!Directory.Exists(BaseFolder)) Directory.CreateDirectory(BaseFolder);
		}

		public static string PatientsPath => Path.Combine(BaseFolder, "patients.csv");
		public static string DoctorsPath => Path.Combine(BaseFolder, "doctors.csv");
		public static string AppointmentsPath => Path.Combine(BaseFolder, "appointments.csv");

		public static List<Patient> LoadPatients()
		{
			EnsureDataFolder();
			var list = new List<Patient>();
			if (!File.Exists(PatientsPath)) return list;
			foreach (var line in File.ReadAllLines(PatientsPath))
			{
				var parts = line.Split(',');
				if (parts.Length < 7) continue;
				var p = new Patient
				{
					Id = Guid.Parse(parts[0]),
					FirstName = parts[1],
					LastName = parts[2],
					DateOfBirth = DateTime.Parse(parts[3], CultureInfo.InvariantCulture),
					MedicalRecordNumber = parts[4],
					PatientType = Enum.TryParse(parts[5], out PatientType t) ? t : PatientType.Outpatient,
					OutstandingBill = double.TryParse(parts[6], out var bill) ? bill : 0
				};
				list.Add(p);
			}
			return list;
		}

		public static void SavePatients(IEnumerable<Patient> patients)
		{
			EnsureDataFolder();
			var lines = new List<string>();
			foreach (var p in patients)
			{
				lines.Add(string.Join(',', new string[]
				{
					p.Id.ToString(),
					p.FirstName,
					p.LastName,
					p.DateOfBirth.ToString(CultureInfo.InvariantCulture),
					p.MedicalRecordNumber,
					p.PatientType.ToString(),
					p.OutstandingBill.ToString(CultureInfo.InvariantCulture)
				}));
			}
			File.WriteAllLines(PatientsPath, lines);
		}

		public static List<Doctor> LoadDoctors()
		{
			EnsureDataFolder();
			var list = new List<Doctor>();
			if (!File.Exists(DoctorsPath)) return list;
			foreach (var line in File.ReadAllLines(DoctorsPath))
			{
				var parts = line.Split(',');
				if (parts.Length < 6) continue;
				var d = new Doctor
				{
					Id = Guid.Parse(parts[0]),
					FirstName = parts[1],
					LastName = parts[2],
					DateOfBirth = DateTime.Parse(parts[3], CultureInfo.InvariantCulture),
					LicenseNumber = parts[4],
					Specialty = Enum.TryParse(parts[5], out Specialty s) ? s : Specialty.General
				};
				list.Add(d);
			}
			return list;
		}

		public static void SaveDoctors(IEnumerable<Doctor> doctors)
		{
			EnsureDataFolder();
			var lines = new List<string>();
			foreach (var d in doctors)
			{
				lines.Add(string.Join(',', new string[]
				{
					d.Id.ToString(),
					d.FirstName,
					d.LastName,
					d.DateOfBirth.ToString(CultureInfo.InvariantCulture),
					d.LicenseNumber,
					d.Specialty.ToString()
				}));
			}
			File.WriteAllLines(DoctorsPath, lines);
		}

		public static List<Appointment> LoadAppointments()
		{
			EnsureDataFolder();
			var list = new List<Appointment>();
			if (!File.Exists(AppointmentsPath)) return list;
			foreach (var line in File.ReadAllLines(AppointmentsPath))
			{
				var parts = line.Split(',');
				if (parts.Length < 5) continue;
				var a = new Appointment
				{
					Id = Guid.Parse(parts[0]),
					PatientId = Guid.Parse(parts[1]),
					DoctorId = Guid.Parse(parts[2]),
					Date = DateTime.Parse(parts[3], CultureInfo.InvariantCulture),
					Notes = parts[4]
				};
				list.Add(a);
			}
			return list;
		}

		public static void SaveAppointments(IEnumerable<Appointment> appointments)
		{
			EnsureDataFolder();
			var lines = new List<string>();
			foreach (var a in appointments)
			{
				lines.Add(string.Join(',', new string[]
				{
					a.Id.ToString(),
					a.PatientId.ToString(),
					a.DoctorId.ToString(),
					a.Date.ToString(CultureInfo.InvariantCulture),
					a.Notes
				}));
			}
			File.WriteAllLines(AppointmentsPath, lines);
		}
	}
}



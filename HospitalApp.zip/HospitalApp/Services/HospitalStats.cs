namespace HospitalApp.Services
{
	public static class HospitalStats
	{
		public static int TotalPatients { get; private set; }
		public static double TotalRevenue { get; private set; }

		public static void IncrementPatients()
		{
			TotalPatients++;
		}

		public static void AddRevenue(double amount)
		{
			if (amount < 0) return;
			TotalRevenue += amount;
		}
	}
}



namespace HospitalApp.Models
{
	public interface IBillable
	{
		double GenerateBill();
	}
}



namespace HospitalApp.Models
{
	public class Doctor : Person
	{
		public Specialty Specialty { get; set; } = Specialty.General;
		public string LicenseNumber { get; set; } = string.Empty;
	}
}



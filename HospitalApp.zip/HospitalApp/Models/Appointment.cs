using System;

namespace HospitalApp.Models
{
	public class Appointment
	{
		public Guid Id { get; set; } = Guid.NewGuid();
		public Guid PatientId { get; set; }
		public Guid DoctorId { get; set; }
		public DateTime Date { get; set; } = DateTime.Now;
		public string Notes { get; set; } = string.Empty;
	}
}



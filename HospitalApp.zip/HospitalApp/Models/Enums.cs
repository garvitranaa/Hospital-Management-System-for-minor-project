namespace HospitalApp.Models
{
	public enum PatientType
	{
		Inpatient,
		Outpatient,
		Emergency
	}

	public enum Specialty
	{
		General,
		Cardiology,
		Neurology,
		Pediatrics,
		Orthopedics
	}
}



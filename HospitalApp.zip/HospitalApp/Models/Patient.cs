using System;

namespace HospitalApp.Models
{
	public class Patient : Person, IBillable
	{
		public PatientType PatientType { get; set; } = PatientType.Outpatient;
		public string MedicalRecordNumber { get; set; } = string.Empty;
		public double OutstandingBill { get; set; }

		public double GenerateBill()
		{
			return OutstandingBill;
		}

		public static bool operator >(Patient a, Patient b)
		{
			return a.GenerateBill() > b.GenerateBill();
		}

		public static bool operator <(Patient a, Patient b)
		{
			return a.GenerateBill() < b.GenerateBill();
		}
	}
}



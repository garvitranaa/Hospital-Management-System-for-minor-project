using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using HospitalApp.Models;
using HospitalApp.Services;

namespace HospitalApp.UI
{
	public class DashboardForm : Form
	{
		private MenuStrip _menu;
		private TabControl _tabs;

		private DataGridView _patientsGrid;
		private DataGridView _doctorsGrid;
		private DataGridView _appointmentsGrid;

		private BindingSource _patientsSource = new BindingSource();
		private BindingSource _doctorsSource = new BindingSource();
		private BindingSource _appointmentsSource = new BindingSource();

		private List<Patient> _patients = new List<Patient>();
		private List<Doctor> _doctors = new List<Doctor>();
		private List<Appointment> _appointments = new List<Appointment>();

		public DashboardForm()
		{
			Text = "Dashboard";
			Width = 1000;
			Height = 600;
			StartPosition = FormStartPosition.CenterScreen;

			_menu = new MenuStrip();
			var fileMenu = new ToolStripMenuItem("File");
			var saveItem = new ToolStripMenuItem("Save All", null, OnSaveAll);
			var statsItem = new ToolStripMenuItem("Show Stats", null, OnShowStats);
			var exitItem = new ToolStripMenuItem("Exit", null, (s, e) => Close());
			fileMenu.DropDownItems.Add(saveItem);
			fileMenu.DropDownItems.Add(statsItem);
			fileMenu.DropDownItems.Add(exitItem);
			_menu.Items.Add(fileMenu);
			MainMenuStrip = _menu;
			Controls.Add(_menu);

			_tabs = new TabControl { Dock = DockStyle.Fill };
			Controls.Add(_tabs);

			CreatePatientsTab();
			CreateDoctorsTab();
			CreateAppointmentsTab();

			LoadData();
		}

		private void CreatePatientsTab()
		{
			var tab = new TabPage("Patients");
			_patientsGrid = new DataGridView { Dock = DockStyle.Fill, AutoGenerateColumns = true };
			_patientsSource.DataSource = _patients;
			_patientsGrid.DataSource = _patientsSource;

			var panel = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 40 };
			var addBtn = new Button { Text = "Add Patient" };
			var delBtn = new Button { Text = "Delete Selected" };
			var saveBtn = new Button { Text = "Save" };
			addBtn.Click += (s, e) =>
			{
				var p = new Patient { FirstName = "New", LastName = "Patient", DateOfBirth = DateTime.Today.AddYears(-20) };
				_patients.Add(p);
				_patientsSource.ResetBindings(false);
				Services.HospitalStats.IncrementPatients();
			};
			delBtn.Click += (s, e) =>
			{
				if (_patientsGrid.CurrentRow?.DataBoundItem is Patient p)
				{
					_patients.Remove(p);
					_patientsSource.ResetBindings(false);
				}
			};
			saveBtn.Click += (s, e) => CsvStorage.SavePatients(_patients);
			panel.Controls.Add(addBtn);
			panel.Controls.Add(delBtn);
			panel.Controls.Add(saveBtn);

			tab.Controls.Add(_patientsGrid);
			tab.Controls.Add(panel);
			_tabs.TabPages.Add(tab);
		}

		private void CreateDoctorsTab()
		{
			var tab = new TabPage("Doctors");
			_doctorsGrid = new DataGridView { Dock = DockStyle.Fill, AutoGenerateColumns = true };
			_doctorsSource.DataSource = _doctors;
			_doctorsGrid.DataSource = _doctorsSource;

			var panel = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 40 };
			var addBtn = new Button { Text = "Add Doctor" };
			var delBtn = new Button { Text = "Delete Selected" };
			var saveBtn = new Button { Text = "Save" };
			addBtn.Click += (s, e) =>
			{
				var d = new Doctor { FirstName = "New", LastName = "Doctor", DateOfBirth = DateTime.Today.AddYears(-30) };
				_doctors.Add(d);
				_doctorsSource.ResetBindings(false);
			};
			delBtn.Click += (s, e) =>
			{
				if (_doctorsGrid.CurrentRow?.DataBoundItem is Doctor d)
				{
					_doctors.Remove(d);
					_doctorsSource.ResetBindings(false);
				}
			};
			saveBtn.Click += (s, e) => CsvStorage.SaveDoctors(_doctors);
			panel.Controls.Add(addBtn);
			panel.Controls.Add(delBtn);
			panel.Controls.Add(saveBtn);

			tab.Controls.Add(_doctorsGrid);
			tab.Controls.Add(panel);
			_tabs.TabPages.Add(tab);
		}

		private void CreateAppointmentsTab()
		{
			var tab = new TabPage("Appointments");
			_appointmentsGrid = new DataGridView { Dock = DockStyle.Fill, AutoGenerateColumns = true };
			_appointmentsSource.DataSource = _appointments;
			_appointmentsGrid.DataSource = _appointmentsSource;

			var panel = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 40 };
			var addBtn = new Button { Text = "Add Appointment" };
			var delBtn = new Button { Text = "Delete Selected" };
			var saveBtn = new Button { Text = "Save" };
			addBtn.Click += (s, e) =>
			{
				if (_patients.Count == 0 || _doctors.Count == 0)
				{
					MessageBox.Show("Need at least one patient and one doctor.");
					return;
				}
				var a = new Appointment
				{
					PatientId = _patients.First().Id,
					DoctorId = _doctors.First().Id,
					Date = DateTime.Now,
					Notes = "New appointment"
				};
				_appointments.Add(a);
				_appointmentsSource.ResetBindings(false);
			};
			delBtn.Click += (s, e) =>
			{
				if (_appointmentsGrid.CurrentRow?.DataBoundItem is Appointment a)
				{
					_appointments.Remove(a);
					_appointmentsSource.ResetBindings(false);
				}
			};
			saveBtn.Click += (s, e) => CsvStorage.SaveAppointments(_appointments);
			panel.Controls.Add(addBtn);
			panel.Controls.Add(delBtn);
			panel.Controls.Add(saveBtn);

			tab.Controls.Add(_appointmentsGrid);
			tab.Controls.Add(panel);
			_tabs.TabPages.Add(tab);
		}

		private void LoadData()
		{
			_patients = CsvStorage.LoadPatients();
			_doctors = CsvStorage.LoadDoctors();
			_appointments = CsvStorage.LoadAppointments();

			_patientsSource.DataSource = _patients;
			_doctorsSource.DataSource = _doctors;
			_appointmentsSource.DataSource = _appointments;
		}

		private void OnSaveAll(object? sender, EventArgs e)
		{
			CsvStorage.SavePatients(_patients);
			CsvStorage.SaveDoctors(_doctors);
			CsvStorage.SaveAppointments(_appointments);
			MessageBox.Show("Saved.");
		}

		private void OnShowStats(object? sender, EventArgs e)
		{
			var revenue = Services.HospitalStats.TotalRevenue;
			var count = Services.HospitalStats.TotalPatients;
			MessageBox.Show($"Patients Added This Session: {count}\nRevenue: {revenue:C}");
		}
	}
}



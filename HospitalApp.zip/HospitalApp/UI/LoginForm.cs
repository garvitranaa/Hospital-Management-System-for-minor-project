using System;
using System.Drawing;
using System.Windows.Forms;

namespace HospitalApp.UI
{
	public class LoginForm : Form
	{
		private TextBox _username;
		private TextBox _password;
		private Button _loginButton;
		private Label _message;

		public LoginForm()
		{
			Text = "Login";
			Width = 400;
			Height = 300;
			StartPosition = FormStartPosition.CenterScreen;

			var userLabel = new Label { Text = "Username", Location = new Point(40, 40), AutoSize = true };
			var passLabel = new Label { Text = "Password", Location = new Point(40, 90), AutoSize = true };
			_username = new TextBox { Location = new Point(140, 36), Width = 180 };
			_password = new TextBox { Location = new Point(140, 86), Width = 180, UseSystemPasswordChar = true };
			_loginButton = new Button { Text = "Login", Location = new Point(140, 140), Width = 100 };
			_message = new Label { Text = "", Location = new Point(40, 180), AutoSize = true, ForeColor = Color.Red };

			_loginButton.Click += LoginButton_Click;

			Controls.Add(userLabel);
			Controls.Add(passLabel);
			Controls.Add(_username);
			Controls.Add(_password);
			Controls.Add(_loginButton);
			Controls.Add(_message);
		}

		private void LoginButton_Click(object? sender, EventArgs e)
		{
			if (string.IsNullOrWhiteSpace(_username.Text) || string.IsNullOrWhiteSpace(_password.Text))
			{
				_message.Text = "Please enter username and password.";
				return;
			}

			if (_username.Text == "admin" && _password.Text == "admin")
			{
				Hide();
				var dashboard = new DashboardForm();
				dashboard.FormClosed += (s, _) => Close();
				dashboard.Show();
			}
			else
			{
				_message.Text = "Invalid credentials.";
			}
		}
	}
}



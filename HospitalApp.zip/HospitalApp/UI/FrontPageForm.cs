using System;
using System.Drawing;
using System.Windows.Forms;

namespace HospitalApp.UI
{
	public class FrontPageForm : Form
	{
		private Label _titleLabel;
		private Button _continueButton;

		public FrontPageForm()
		{
			Text = "Hospital Patient Record System";
			Width = 800;
			Height = 500;
			StartPosition = FormStartPosition.CenterScreen;

			_titleLabel = new Label
			{
				Text = "Welcome to Hospital System",
				Font = new Font(FontFamily.GenericSansSerif, 20, FontStyle.Bold),
				AutoSize = true,
				Location = new Point(200, 120)
			};

			_continueButton = new Button
			{
				Text = "Continue",
				Width = 120,
				Height = 40,
				Location = new Point(340, 240)
			};
			_continueButton.Click += ContinueButton_Click;

			Controls.Add(_titleLabel);
			Controls.Add(_continueButton);
		}

		private void ContinueButton_Click(object? sender, EventArgs e)
		{
			Hide();
			var login = new LoginForm();
			login.FormClosed += (s, _) => Close();
			login.Show();
		}
	}
}



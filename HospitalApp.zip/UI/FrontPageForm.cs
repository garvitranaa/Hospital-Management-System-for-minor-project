using System.Windows.Forms;

namespace HospitalApp.UI
{
    public class FrontPageForm : Form
    {
        private Label titleLabel;
        private Button startButton;

        public FrontPageForm()
        {
            Text = "Hospital Patient Record System";
            Width = 600;
            Height = 400;
            StartPosition = FormStartPosition.CenterScreen;

            titleLabel = new Label
            {
                Text = "Welcome to Hospital System",
                AutoSize = true,
                Font = new System.Drawing.Font("Segoe UI", 18, System.Drawing.FontStyle.Bold),
                Top = 80,
                Left = 80
            };

            startButton = new Button
            {
                Text = "Get Started",
                Width = 140,
                Height = 40,
                Top = 180,
                Left = 80
            };
            startButton.Click += (s, e) =>
            {
                var login = new LoginForm();
                login.Show();
                Hide();
            };

            Controls.Add(titleLabel);
            Controls.Add(startButton);
        }
    }
}








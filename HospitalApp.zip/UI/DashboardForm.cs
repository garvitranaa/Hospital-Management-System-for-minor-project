using HospitalApp.Models;
using HospitalApp.Services;
using System.ComponentModel;
using System.Windows.Forms;

namespace HospitalApp.UI
{
    public class DashboardForm : Form
    {
        private TabControl tabs;
        private DataGridView gridPatients;
        private DataGridView gridDoctors;
        private DataGridView gridAppointments;
        private MenuStrip menu;
        private ToolStripStatusLabel statusLabel;

        private BindingList<Patient> patients;
        private BindingList<Doctor> doctors;
        private BindingList<Appointment> appointments;

        public DashboardForm()
        {
            Text = "Dashboard";
            Width = 900;
            Height = 600;
            StartPosition = FormStartPosition.CenterScreen;

            menu = new MenuStrip();
            var fileMenu = new ToolStripMenuItem("File");
            var saveItem = new ToolStripMenuItem("Save All");
            var loadItem = new ToolStripMenuItem("Load All");
            var exitItem = new ToolStripMenuItem("Exit");
            saveItem.Click += (s, e) => SaveAll();
            loadItem.Click += (s, e) => LoadAll();
            exitItem.Click += (s, e) => Close();
            fileMenu.DropDownItems.AddRange(new ToolStripItem[] { saveItem, loadItem, exitItem });
            menu.Items.Add(fileMenu);
            Controls.Add(menu);

            var status = new StatusStrip();
            statusLabel = new ToolStripStatusLabel("Ready");
            status.Items.Add(statusLabel);
            Controls.Add(status);

            tabs = new TabControl { Dock = DockStyle.Fill, Top = menu.Height };

            gridPatients = new DataGridView { Dock = DockStyle.Fill, AutoGenerateColumns = true };
            gridDoctors = new DataGridView { Dock = DockStyle.Fill, AutoGenerateColumns = true };
            gridAppointments = new DataGridView { Dock = DockStyle.Fill, AutoGenerateColumns = true };

            var tabPatients = new TabPage("Patients");
            var tabDoctors = new TabPage("Doctors");
            var tabAppointments = new TabPage("Appointments");

            var patientPanel = BuildPatientPanel();
            var doctorPanel = BuildDoctorPanel();
            var apptPanel = BuildAppointmentPanel();

            tabPatients.Controls.Add(patientPanel);
            tabDoctors.Controls.Add(doctorPanel);
            tabAppointments.Controls.Add(apptPanel);

            tabs.TabPages.Add(tabPatients);
            tabs.TabPages.Add(tabDoctors);
            tabs.TabPages.Add(tabAppointments);

            Controls.Add(tabs);

            LoadAll();
        }

        private Control BuildPatientPanel()
        {
            var panel = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2 };
            panel.RowStyles.Add(new RowStyle(SizeType.Percent, 70));
            panel.RowStyles.Add(new RowStyle(SizeType.Percent, 30));
            panel.Controls.Add(gridPatients, 0, 0);

            var formPanel = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoScroll = true };
            var txtFirst = new TextBox { Width = 120, PlaceholderText = "First Name" };
            var txtLast = new TextBox { Width = 120, PlaceholderText = "Last Name" };
            var txtPhone = new TextBox { Width = 120, PlaceholderText = "Phone" };
            var txtEmail = new TextBox { Width = 160, PlaceholderText = "Email" };
            var cmbType = new ComboBox { Width = 120, DataSource = Enum.GetValues(typeof(PatientType)) };
            var txtBill = new TextBox { Width = 80, PlaceholderText = "Bill" };
            var btnAdd = new Button { Text = "Add", Width = 80 };
            var btnRemove = new Button { Text = "Remove Selected", Width = 140 };
            var btnPay = new Button { Text = "Add Revenue", Width = 120 };

            btnAdd.Click += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(txtFirst.Text) || string.IsNullOrWhiteSpace(txtLast.Text))
                {
                    throw new InvalidPatientException("First and Last name are required.");
                }
                var p = new Patient
                {
                    FirstName = txtFirst.Text,
                    LastName = txtLast.Text,
                    Phone = txtPhone.Text,
                    Email = txtEmail.Text,
                    Type = (PatientType)cmbType.SelectedItem,
                    OutstandingBill = decimal.TryParse(txtBill.Text, out var b) ? b : 0
                };
                patients.Add(p);
                HospitalStats.IncrementPatients();
                statusLabel.Text = $"Patients: {HospitalStats.TotalPatients}, Revenue: {HospitalStats.TotalRevenue:C}";
            };

            btnRemove.Click += (s, e) =>
            {
                if (gridPatients.CurrentRow?.DataBoundItem is Patient sel)
                {
                    patients.Remove(sel);
                }
            };

            btnPay.Click += (s, e) =>
            {
                if (gridPatients.CurrentRow?.DataBoundItem is Patient sel)
                {
                    try
                    {
                        var amount = sel.GenerateBill();
                        if (amount < 0) throw new BillingException("Invalid bill amount.");
                        HospitalStats.AddRevenue(amount);
                        sel.OutstandingBill = 0;
                        gridPatients.Refresh();
                        statusLabel.Text = $"Patients: {HospitalStats.TotalPatients}, Revenue: {HospitalStats.TotalRevenue:C}";
                    }
                    catch (BillingException ex)
                    {
                        MessageBox.Show(ex.Message, "Billing Error");
                    }
                }
            };

            formPanel.Controls.AddRange(new Control[] { txtFirst, txtLast, txtPhone, txtEmail, cmbType, txtBill, btnAdd, btnRemove, btnPay });
            panel.Controls.Add(formPanel, 0, 1);
            return panel;
        }

        private Control BuildDoctorPanel()
        {
            var panel = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2 };
            panel.RowStyles.Add(new RowStyle(SizeType.Percent, 70));
            panel.RowStyles.Add(new RowStyle(SizeType.Percent, 30));
            panel.Controls.Add(gridDoctors, 0, 0);

            var formPanel = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoScroll = true };
            var txtFirst = new TextBox { Width = 120, PlaceholderText = "First Name" };
            var txtLast = new TextBox { Width = 120, PlaceholderText = "Last Name" };
            var txtPhone = new TextBox { Width = 120, PlaceholderText = "Phone" };
            var txtEmail = new TextBox { Width = 160, PlaceholderText = "Email" };
            var cmbSpec = new ComboBox { Width = 140, DataSource = Enum.GetValues(typeof(Specialty)) };
            var txtRoom = new TextBox { Width = 80, PlaceholderText = "Room" };
            var btnAdd = new Button { Text = "Add", Width = 80 };
            var btnRemove = new Button { Text = "Remove Selected", Width = 140 };

            btnAdd.Click += (s, e) =>
            {
                var d = new Doctor
                {
                    FirstName = txtFirst.Text,
                    LastName = txtLast.Text,
                    Phone = txtPhone.Text,
                    Email = txtEmail.Text,
                    Specialty = (Specialty)cmbSpec.SelectedItem,
                    Room = txtRoom.Text
                };
                doctors.Add(d);
            };

            btnRemove.Click += (s, e) =>
            {
                if (gridDoctors.CurrentRow?.DataBoundItem is Doctor sel)
                {
                    doctors.Remove(sel);
                }
            };

            formPanel.Controls.AddRange(new Control[] { txtFirst, txtLast, txtPhone, txtEmail, cmbSpec, txtRoom, btnAdd, btnRemove });
            panel.Controls.Add(formPanel, 0, 1);
            return panel;
        }

        private Control BuildAppointmentPanel()
        {
            var panel = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2 };
            panel.RowStyles.Add(new RowStyle(SizeType.Percent, 70));
            panel.RowStyles.Add(new RowStyle(SizeType.Percent, 30));
            panel.Controls.Add(gridAppointments, 0, 0);

            var formPanel = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoScroll = true };
            var cmbPatient = new ComboBox { Width = 180, DropDownStyle = ComboBoxStyle.DropDownList };
            var cmbDoctor = new ComboBox { Width = 180, DropDownStyle = ComboBoxStyle.DropDownList };
            var dtDate = new DateTimePicker { Width = 160 };
            var txtNotes = new TextBox { Width = 200, PlaceholderText = "Notes" };
            var btnAdd = new Button { Text = "Add", Width = 80 };
            var btnRemove = new Button { Text = "Remove Selected", Width = 140 };

            btnAdd.Click += (s, e) =>
            {
                if (cmbPatient.SelectedItem is Patient p && cmbDoctor.SelectedItem is Doctor d)
                {
                    var a = new Appointment
                    {
                        PatientId = p.Id,
                        DoctorId = d.Id,
                        Date = dtDate.Value,
                        Notes = txtNotes.Text
                    };
                    appointments.Add(a);
                }
            };

            btnRemove.Click += (s, e) =>
            {
                if (gridAppointments.CurrentRow?.DataBoundItem is Appointment sel)
                {
                    appointments.Remove(sel);
                }
            };

            formPanel.Controls.AddRange(new Control[] { cmbPatient, cmbDoctor, dtDate, txtNotes, btnAdd, btnRemove });
            panel.Controls.Add(formPanel, 0, 1);

            // Bind sources when data is loaded
            Load += (s, e) =>
            {
                cmbPatient.DataSource = patients;
                cmbPatient.DisplayMember = nameof(Patient.FullName);
                cmbDoctor.DataSource = doctors;
                cmbDoctor.DisplayMember = nameof(Person.FullName);
            };

            return panel;
        }

        private void LoadAll()
        {
            patients = new BindingList<Patient>(Storage.LoadPatients());
            doctors = new BindingList<Doctor>(Storage.LoadDoctors());
            appointments = new BindingList<Appointment>(Storage.LoadAppointments());

            gridPatients.DataSource = patients;
            gridDoctors.DataSource = doctors;
            gridAppointments.DataSource = appointments;
            statusLabel.Text = $"Patients: {patients.Count}, Revenue: {HospitalStats.TotalRevenue:C}";
        }

        private void SaveAll()
        {
            Storage.SavePatients(patients);
            Storage.SaveDoctors(doctors);
            Storage.SaveAppointments(appointments);
            statusLabel.Text = "Saved.";
        }
    }
}








using System.Windows.Forms;

namespace HospitalApp.UI
{
    public class LoginForm : Form
    {
        private TextBox txtUser;
        private TextBox txtPass;
        private Button btnLogin;
        private Label lblInfo;

        public LoginForm()
        {
            Text = "Login";
            Width = 400;
            Height = 280;
            StartPosition = FormStartPosition.CenterScreen;

            lblInfo = new Label { Text = "Enter credentials (user: admin, pass: admin)", AutoSize = true, Top = 20, Left = 20 };
            var lblUser = new Label { Text = "Username:", AutoSize = true, Top = 60, Left = 20 };
            var lblPass = new Label { Text = "Password:", AutoSize = true, Top = 100, Left = 20 };
            txtUser = new TextBox { Top = 56, Left = 120, Width = 200 };
            txtPass = new TextBox { Top = 96, Left = 120, Width = 200, UseSystemPasswordChar = true };
            btnLogin = new Button { Text = "Login", Top = 140, Left = 120, Width = 100 };

            btnLogin.Click += (s, e) =>
            {
                if (txtUser.Text == "admin" && txtPass.Text == "admin")
                {
                    var dash = new DashboardForm();
                    dash.Show();
                    Hide();
                }
                else
                {
                    MessageBox.Show("Invalid username or password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            };

            Controls.Add(lblInfo);
            Controls.Add(lblUser);
            Controls.Add(lblPass);
            Controls.Add(txtUser);
            Controls.Add(txtPass);
            Controls.Add(btnLogin);
        }
    }
}








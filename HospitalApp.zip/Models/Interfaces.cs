namespace HospitalApp.Models
{
    public interface IBillable
    {
        decimal GenerateBill();
    }
}





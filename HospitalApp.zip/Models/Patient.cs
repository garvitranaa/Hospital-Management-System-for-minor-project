namespace HospitalApp.Models
{
    public class Patient : Person, IBillable
    {
        public PatientType Type { get; set; } = PatientType.Outpatient;
        public decimal OutstandingBill { get; set; }

        public decimal GenerateBill()
        {
            return OutstandingBill;
        }

        public static bool operator >(Patient a, Patient b)
        {
            return a.GenerateBill() > b.GenerateBill();
        }

        public static bool operator <(Patient a, Patient b)
        {
            return a.GenerateBill() < b.GenerateBill();
        }
    }
}





namespace HospitalApp.Models
{
    public class InvalidPatientException : Exception
    {
        public InvalidPatientException(string message) : base(message) { }
    }

    public class BillingException : Exception
    {
        public BillingException(string message) : base(message) { }
    }
}








namespace HospitalApp.Models
{
    public class Doctor : Person
    {
        public Specialty Specialty { get; set; } = Specialty.General;
        public string Room { get; set; } = string.Empty;
    }
}




